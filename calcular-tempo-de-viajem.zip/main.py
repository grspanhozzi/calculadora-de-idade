from flask import Flask, render_template, request

app = Flask(__name__)

# Rota principal
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Obter os dados do formulário
        distancia = float(request.form["distancia"])
        velocidade = float(request.form["velocidade"])

        # Calcular o tempo de viagem
        tempo = distancia / velocidade  # Tempo = Distância / Velocidade

        # Passar o resultado para o template
        return render_template("index.html", tempo=tempo)

    return render_template("index.html", tempo=None)

if __name__ == "__main__":
    app.run(debug=True)
