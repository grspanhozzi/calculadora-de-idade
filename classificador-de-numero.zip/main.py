from flask import Flask, render_template, request
app = Flask(__name__)
# Rota principal
@app.route("/", methods=["GET", "POST"])
def index():
    resultado = None

    if request.method == "POST":
        try:
            # Obter o número informado pelo usuário
            numero = int(request.form["numero"])

            # Determinar se o número é par ou ímpar
            if numero % 2 == 0:
                par_impar = "par"
            else:
                par_impar = "ímpar"

            # Determinar se o número é positivo, negativo ou zero
            if numero > 0:
                positivo_negativo = "positivo"
            elif numero < 0:
                positivo_negativo = "negativo"
            else:
                positivo_negativo = "zero"

            # Resultado final
            resultado = f"O número {numero} é {par_impar} e {positivo_negativo}."

        except ValueError:
            resultado = "Por favor, insira um número inteiro válido."

    return render_template("index.html", resultado=resultado)

if __name__ == "__main__":
    app.run(debug=True)