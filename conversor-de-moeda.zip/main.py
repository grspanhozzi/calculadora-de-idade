from flask import Flask, render_template, request

app = Flask(__name__)


# Função para converter o valor de reais para diferentes moedas
def converter_moeda(valor_reais, moeda):
    # Dicionário com taxas de conversão
    taxas = {
        "dolar": 5.25,  # Exemplo: 1 real = 5.25 dólares
        "euro": 5.75,  # Exemplo: 1 real = 5.75 euros
    }

    if moeda.lower() in taxas:
        return valor_reais / taxas[moeda.lower()]
    else:
        return None  # Se a moeda não estiver no dicionário


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        try:
            valor_reais = float(request.form["valor_reais"])
            moeda = request.form["moeda"]

            valor_convertido = converter_moeda(valor_reais, moeda)

            if valor_convertido is None:
                resultado = "Erro: Moeda não reconhecida. Escolha 'dolar' ou 'euro'."
            else:
                resultado = f"{valor_reais} reais é igual a {valor_convertido:.2f} {moeda.capitalize()}."

        except ValueError:
            resultado = "Por favor, insira um valor numérico válido para os reais."

        return render_template("index.html", resultado=resultado)

    return render_template("index.html", resultado=None)


if __name__ == "__main__":
    app.run(debug=True)
