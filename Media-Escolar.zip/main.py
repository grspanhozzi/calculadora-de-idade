from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def calcular_media():
    if request.method == 'POST':
        # Pegando as notas enviadas pelo formulário
        try:
            nota1 = float(request.form['nota1'])
            nota2 = float(request.form['nota2'])
            nota3 = float(request.form['nota3'])

            # Calculando a média
            media = (nota1 + nota2 + nota3) / 3

            # Verificando se o aluno foi aprovado ou reprovado
            if media >= 7:
                situacao = 'Aprovado'
            else:
                situacao = 'Reprovado'

            # Retornando a média e a situação
            return render_template('index.html', media=media, situacao=situacao)

        except ValueError:
            return render_template('index.html', erro="Por favor, insira valores válidos para as notas.")

    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
